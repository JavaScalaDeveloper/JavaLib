package Reflect.Homework;

/*
利用反射获取已知Student类实现的接口的泛型（已知类为：课堂案例Student类）
@author 黄佳豪
@create 2019-07-29-20:42
*/
public class Hw3 {
}
