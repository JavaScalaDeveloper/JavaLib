package Java8.Lambda;

/*
@author 黄佳豪
@create 2019-07-31-14:53
演示构造器的引用
*/
public class ConstructorRef {

}
