package IOStream.PrintStream;

/*
@author 黄佳豪
@create 2019-07-27-10:40
*/
public class PrintStreamDemo {
    public static void main(String[] args) {
        System.out.printf("%f", 3.1415926);

    }
}
