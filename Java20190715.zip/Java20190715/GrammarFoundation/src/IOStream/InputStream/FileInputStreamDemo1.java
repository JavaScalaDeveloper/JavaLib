package IOStream.InputStream;


/*
@author 黄佳豪
@create 2019-07-26-11:47
*/
public class FileInputStreamDemo1 {

}
