package Enum.atguigu.exception;

public class TestException3 {
	
	public static void main(String[] args) {
//		try{
//			int age = Integer.parseInt(args[0]);
//		
//		}catch(NumberFormatException e){
//			//具体的处理语句
//			//方式一：打印错误追踪日志
////			e.printStackTrace();
//			//方式二：打印友好提示
////			System.out.println("没有传入有效的数值");
//			
//			//方式三：打印错误信息
//			System.out.println("出错了，原因是："+e.getMessage());
//			
//		}
		
		

	}

}
