# 1.显示所有员工的姓名，部门号和部门名称。



# 2.查询90号部门员工的job_id和90号部门的location_id



# 3.选择所有有奖金的员工的 last_name , department_name , location_id , city



# 4.选择city在Toronto工作的员工的 last_name , job_id , department_id , department_name 



# 5.选择指定员工的姓名，员工号，以及他的管理者的姓名和员工号，结果类似于下面的格式
employees	Emp#	manager	Mgr#
kochhar		101	king	100



