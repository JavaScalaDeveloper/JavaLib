# 1.显示系统时间(注：日期+时间)


# 2.查询员工号，姓名，工资，以及工资提高百分之20%后的结果（new salary）



# 3.将员工的姓名按首字母排序，并写出姓名的长度（length）



-- 4.做一个查询，产生下面的结果
-- <last_name> earns <salary> monthly but wants <salary*3> Dream Salary
-- King earns 24000 monthly but wants 72000



-- 5.	使用case-when，按照下面的条件：
-- job                  grade
-- AD_PRES              A
-- ST_MAN               B
-- IT_PROG              C
-- SA_REP               D
-- ST_CLERK             E

-- 产生下面的结果
-- Last_name	Job_id	Grade
-- king	       AD_PRES	A


