package cn.hjhstudy.TeamSchedular.service;

/*
@author 黄佳豪
@create 2019-07-24-10:20
*/
public class TeamException extends RuntimeException {
    public TeamException(String message) {
        super(message);
    }

    public TeamException() {
    }
}
