package cn.hjhstudy.TeamSchedular.domain;

public enum Status {
	
	FREE,BUSY,VOCATION;

}
