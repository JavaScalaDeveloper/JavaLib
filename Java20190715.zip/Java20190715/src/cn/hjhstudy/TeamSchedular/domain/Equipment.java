package cn.hjhstudy.TeamSchedular.domain;

public interface Equipment {

	
	public String getDescription();
}
